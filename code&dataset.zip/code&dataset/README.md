# Code for MV-S²M

## Abstract

CircRNA-miRNA interactions (CMIs) play critical regulatory roles in human diseases and holds promise for therapeutic targeting. However, most existing prediction methods rely primarily on circRNA-miRNA pairs and overlook disease-level regulatory contexts, which limits their ability to characterize cross-pathway dependencies in zero-shot inference. To address this, we propose MV-S²M, a Multi-View State-Space Modeling framework that integrates molecular priors to enhance relational reasoning, enabling zero-shot CMI prediction. Specifically, we employ structure-aware diffusion to enrich molecular priors across the network, including circRNA functional similarity, disease ontology semantics, and miRNA sequence embeddings. We then construct disease-mediated subgraphs and encode them using a state-space modeling module, which captures long-range dependencies and view-specific regulatory patterns. A linear layer fuses representations from different subgraphs and feeds them into a multilayer perceptron for CMI prediction. Extensive experiments on multiple benchmark datasets demonstrate that MV-S²M achieves state-of-the-art performance under both zero-shot and conventional settings. Additionally, case studies highlight the contribution of meta-path-guided semantic subgraphs to improving prediction reliability.

## Prerequisites

WSL installed on Windows (preferably WSL2). Recommended Linux distribution: Ubuntu 20.04 or later.

## Setup Environment

We recommend setting up the environment using [Anaconda](https://docs.anaconda.com/anaconda/install/index.html).

## Depedencies:

python>=3.10
torch=2.3.1+cu118
torchaudio=2.3.1+cu118
torchvision=0.18.1+cu118
triton=2.3.1
transformers=4.43.3
causal-conv1d=1.4.0
mamba-ssm =2.2.2
cuda-nvcc=1.8.89

