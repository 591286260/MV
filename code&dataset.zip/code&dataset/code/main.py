import os
import csv
import random
import numpy as np
import pandas as pd
import networkx as nx
import torch
import matplotlib.pyplot as plt

from tqdm import tqdm
from mamba_ssm import Mamba
from torch_geometric.data import Data

from sklearn.model_selection import KFold
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    roc_curve, auc, precision_recall_curve, average_precision_score,
    classification_report, precision_recall_fscore_support,
    accuracy_score, matthews_corrcoef, confusion_matrix
)
from numpy import interp


def set_seed(seed=60):
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def build_graph(circ_disease_csv, mir_disease_csv):
    df_circ = pd.read_csv(circ_disease_csv, header=None, names=["circ", "disease"])
    df_mir = pd.read_csv(mir_disease_csv, header=None, names=["mir", "disease"])

    G = nx.Graph()
    for _, r in df_circ.iterrows():
        G.add_node(r["circ"], type="circRNA")
        G.add_node(r["disease"], type="disease")
        G.add_edge(r["circ"], r["disease"])

    for _, r in df_mir.iterrows():
        G.add_node(r["mir"], type="miRNA")
        G.add_node(r["disease"], type="disease")
        G.add_edge(r["mir"], r["disease"])

    return G


def load_node_features(se_vector_csv, G):
    df_feat = pd.read_csv(se_vector_csv, header=None)
    df_feat.columns = ["id"] + [f"f{i}" for i in range(1, df_feat.shape[1])]
    node_feat_map = df_feat.set_index("id").T.to_dict("list")

    node_to_idx = {n: i for i, n in enumerate(G.nodes())}
    idx_to_node = {i: n for n, i in node_to_idx.items()}

    edges = []
    for u, v in G.edges():
        edges.append((node_to_idx[u], node_to_idx[v]))
        edges.append((node_to_idx[v], node_to_idx[u]))
    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()

    num_nodes = G.number_of_nodes()
    feat_dim = len(next(iter(node_feat_map.values())))
    x = torch.zeros((num_nodes, feat_dim), dtype=torch.float32)
    for node, feat in node_feat_map.items():
        if node in node_to_idx:
            x[node_to_idx[node]] = torch.tensor(feat, dtype=torch.float32)

    data = Data(edge_index=edge_index, x=x)
    return data, node_to_idx, idx_to_node, feat_dim


def add_gaussian_noise(x, std=0.01):
    return x + torch.randn_like(x) * std


def build_homogeneous_edge_index(G, node_to_idx, intermediate_nodes, inter_type, end_type, subgraph_name):
    edges = []
    for inter in tqdm(intermediate_nodes, desc=f"Building subgraph {subgraph_name}"):
        if G.nodes[inter]["type"] != inter_type:
            continue

        ends = [v for v in G.neighbors(inter) if G.nodes[v]["type"] == end_type]
        if len(ends) < 2:
            continue

        for i in range(len(ends)):
            for j in range(i + 1, len(ends)):
                if end_type == "disease":
                    edges.append((node_to_idx[ends[i]], node_to_idx[inter]))
                    edges.append((node_to_idx[ends[j]], node_to_idx[inter]))
                else:
                    edges.append((node_to_idx[inter], node_to_idx[ends[i]]))
                    edges.append((node_to_idx[inter], node_to_idx[ends[j]]))

    if len(edges) == 0:
        return torch.empty((2, 0), dtype=torch.long)
    return torch.tensor(edges, dtype=torch.long).t().contiguous()


def count_subgraph_nodes(edge_idx_dict, node_to_idx, G):
    node_types = nx.get_node_attributes(G, "type")
    idx_to_node_local = {i: n for n, i in node_to_idx.items()}

    for name, eidx in edge_idx_dict.items():
        if eidx.numel() == 0:
            print(f"Subgraph {name} is empty")
            continue

        nodes = torch.unique(eidx).cpu().numpy()
        circ_count = mir_count = disease_count = 0
        for idx in nodes:
            node = idx_to_node_local[int(idx)]
            t = node_types[node]
            if t == "circRNA":
                circ_count += 1
            elif t == "miRNA":
                mir_count += 1
            elif t == "disease":
                disease_count += 1
        print(f"Subgraph {name}: circRNA {circ_count}, miRNA {mir_count}, disease {disease_count}")


class CausalMambaBlock(torch.nn.Module):
    def __init__(self, d_model, d_state=16, d_conv=4, expand=2):
        super().__init__()
        self.mamba = Mamba(d_model=d_model, d_state=d_state, d_conv=d_conv, expand=expand)
        self.norm = torch.nn.LayerNorm(d_model)

    def forward(self, x):
        residual = x
        x = self.mamba(x)
        return self.norm(x + residual)


class HMMPModel(torch.nn.Module):
    def __init__(
        self,
        in_c,
        out_c,
        edge_idx_dict,
        num_layers=3,
        diffusion_alpha=0.2,
        num_diffusion_steps=15,
        dropout=0.2,
    ):
        super().__init__()
        self.edge_idx_dict = edge_idx_dict
        self.dropout = torch.nn.Dropout(dropout)

        self.diffusion_alpha = diffusion_alpha
        self.num_diffusion_steps = num_diffusion_steps

        self.h_dim = in_c
        self.subgraph_mambas = torch.nn.ModuleDict()
        for name in edge_idx_dict:
            self.subgraph_mambas[name] = torch.nn.ModuleList(
                [CausalMambaBlock(d_model=self.h_dim) for _ in range(num_layers)]
            )

        self.fuse = torch.nn.Linear(self.h_dim * len(edge_idx_dict), out_c)
        self.res = torch.nn.Sequential(torch.nn.Linear(in_c, out_c), torch.nn.ReLU())
        self.layernorm = torch.nn.LayerNorm(out_c)

    def diffusion_step(self, x, edge_index):
        num_nodes = x.size(0)
        adj = torch.zeros((num_nodes, num_nodes), device=x.device, dtype=x.dtype)
        adj[edge_index[0], edge_index[1]] = 1.0
        deg = adj.sum(dim=1, keepdim=True)
        deg[deg == 0] = 1.0
        adj = adj / deg

        x0 = x
        for _ in range(self.num_diffusion_steps):
            x = (1 - self.diffusion_alpha) * (adj @ x) + self.diffusion_alpha * x0
        return x

    def forward(self, x, edge_index):
        r = self.res(x)

        x_d = self.diffusion_step(x, edge_index)
        x_d = torch.relu(x_d)
        x_d = self.dropout(x_d)

        num_nodes = x_d.size(0)
        num_sub = len(self.edge_idx_dict)
        x_cat = torch.zeros((num_nodes, self.h_dim * num_sub), device=x_d.device, dtype=x_d.dtype)

        col = 0
        for name, eidx in self.edge_idx_dict.items():
            if eidx.numel() == 0:
                col += self.h_dim
                continue

            nodes = torch.unique(eidx).to(x_d.device)
            if nodes.numel() == 0:
                col += self.h_dim
                continue

            x_sub = x_d[nodes].unsqueeze(0)
            for layer in self.subgraph_mambas[name]:
                x_sub = layer(x_sub)

            x_mamba = self.dropout(x_sub.squeeze(0))
            x_cat[nodes, col: col + self.h_dim] = x_mamba
            col += self.h_dim

        fused = self.fuse(x_cat)
        out = self.layernorm(fused + r)
        return out


def train_hmmp_and_export_embeddings(
    G,
    data,
    edge_idx_dict,
    out_node_emb_csv="node_embeddings.csv",
    seed=60,
    lr=1e-3,
    epochs=200,
    weight_decay=1e-5,
    w_recon=1.0,
    noise_std=0.01,
):
    device = get_device()
    data = data.to(device)

    num_nodes = data.x.size(0)
    num_train = int(0.8 * num_nodes)
    perm = torch.randperm(num_nodes, device=device)
    train_mask = torch.zeros(num_nodes, dtype=torch.bool, device=device)
    val_mask = torch.zeros(num_nodes, dtype=torch.bool, device=device)
    train_mask[perm[:num_train]] = True
    val_mask[perm[num_train:]] = True

    edge_idx_dict = {k: v.to(device) for k, v in edge_idx_dict.items()}

    data.x = add_gaussian_noise(data.x, std=noise_std)

    feat_dim = data.x.size(1)
    model = HMMPModel(feat_dim, feat_dim, edge_idx_dict, num_layers=3, dropout=0.2).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    criterion = torch.nn.MSELoss()

    scaler = torch.cuda.amp.GradScaler(enabled=(device.type == "cuda"))

    for epoch in tqdm(range(1, epochs + 1), desc="HMMP Epoch"):
        model.train()
        optimizer.zero_grad(set_to_none=True)

        with torch.cuda.amp.autocast(enabled=(device.type == "cuda")):
            out = model(data.x, data.edge_index)
            loss_recon = criterion(out[train_mask], data.x[train_mask])
            loss = w_recon * loss_recon

        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        model.eval()
        with torch.no_grad():
            out_val = model(data.x, data.edge_index)
            val_loss = criterion(out_val[val_mask], data.x[val_mask])

        if epoch == 1 or epoch % 10 == 0:
            print(f"[{epoch}/{epochs}] Train Loss: {loss_recon.item():.6f} | Val Loss: {val_loss.item():.6f}")

    model.eval()
    with torch.no_grad():
        emb = model(data.x, data.edge_index).detach().cpu().numpy()

    df_emb = pd.DataFrame(emb, index=list(G.nodes()))
    df_emb.to_csv(out_node_emb_csv, header=False)
    print(f"Node embeddings saved to: {out_node_emb_csv}")


def read_feature_file(feature_csv, encoding="gbk"):
    feature_dict = {}
    with open(feature_csv, "r", encoding=encoding) as f:
        reader = csv.reader(f)
        for row in reader:
            if not row:
                continue
            feature_dict[row[0]] = row[1:]
    return feature_dict


def replace_id_pair_with_feature_pair(input_pair_csv, feature_dict, output_feature_csv, encoding="gbk"):
    missing = 0
    with open(input_pair_csv, "r", encoding=encoding) as fin, open(output_feature_csv, "w", newline="", encoding=encoding) as fout:
        w = csv.writer(fout)
        for row in csv.reader(fin):
            if len(row) < 2:
                continue
            id1, id2 = row[0], row[1]
            f1 = feature_dict.get(id1)
            f2 = feature_dict.get(id2)
            if f1 is None or f2 is None:
                missing += 1
                continue
            w.writerow(f1 + f2)

    if missing > 0:
        print(f"[Warning] {missing} rows were skipped due to missing node features.")
    print(f"Sample features saved to: {output_feature_csv}")


def load_features(file_path):
    return np.loadtxt(file_path, delimiter=",")


def train_and_evaluate_fold(clf, X_train, y_train, X_test, y_test, fold, output_file):
    clf.fit(X_train, y_train)

    y_pred_prob = clf.predict_proba(X_test)[:, 1]
    y_pred = (y_pred_prob > 0.5).astype(int)

    precision, recall, f1_score, _ = precision_recall_fscore_support(y_test, y_pred, average="binary")
    accuracy = accuracy_score(y_test, y_pred)
    mcc = matthews_corrcoef(y_test, y_pred)

    tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()
    specificity = tn / (tn + fp + 1e-12)

    fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
    roc_auc = auc(fpr, tpr)

    aupr = average_precision_score(y_test, y_pred_prob)

    np.save(f"Y_pre{fold - 1}.npy", y_pred_prob)
    np.save(f"Y_test{fold - 1}.npy", y_test)

    print(f"\nFold {fold}:")
    print(classification_report(y_test, y_pred))
    print(f"Accuracy: {accuracy:.4f}, Precision: {precision:.4f}, Recall: {recall:.4f}")
    print(f"Specificity: {specificity:.4f}, F1-score: {f1_score:.4f}, MCC: {mcc:.4f}")
    print(f"AUC: {roc_auc:.4f}, AUPR: {aupr:.4f}")

    with open(output_file, "a") as f:
        f.write(
            f"{fold}\t{accuracy:.4f}\t{precision:.4f}\t{recall:.4f}\t{specificity:.4f}\t"
            f"{f1_score:.4f}\t{mcc:.4f}\t{roc_auc:.4f}\t{aupr:.4f}\n"
        )

    return precision, recall, f1_score, accuracy, mcc, specificity, roc_auc, aupr


def plot_roc_curves(n_folds=5, save_path="AUC.tif"):
    tprs = []
    aucs = []
    mean_fpr = np.linspace(0, 1, 10000)

    plt.figure()
    for i in range(n_folds):
        predicted = np.load(f"Y_pre{i}.npy")
        true_labels = np.load(f"Y_test{i}.npy")

        fpr, tpr, _ = roc_curve(true_labels, predicted)
        roc_auc = auc(fpr, tpr)
        aucs.append(roc_auc)

        tprs.append(interp(mean_fpr, fpr, tpr))
        tprs[-1][0] = 0.0
        plt.plot(fpr, tpr, lw=1.5, label=f"ROC fold {i + 1} (AUC = {roc_auc:.4f})")

    plt.plot([0, 1], [0, 1], linestyle="--", lw=1, alpha=0.5)

    mean_tpr = np.mean(tprs, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = auc(mean_fpr, mean_tpr)
    std_auc = np.std(aucs, ddof=1)

    plt.plot(mean_fpr, mean_tpr, lw=1.5, label=f"Mean ROC (AUC = {mean_auc:.4f} ± {std_auc:.4f})")
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.legend(loc="lower right")
    plt.savefig(save_path)
    plt.show()

    return mean_auc, std_auc


def plot_pr_curves(n_folds=5, save_path="AUPR.tif"):
    mean_R = np.linspace(0, 1, 1000)
    Ps = []
    RPs = []

    plt.figure()
    for i in range(n_folds):
        predicted = np.load(f"Y_pre{i}.npy")
        true_labels = np.load(f"Y_test{i}.npy")

        precision, recall, _ = precision_recall_curve(true_labels, predicted)
        aupr = average_precision_score(true_labels, predicted)
        RPs.append(aupr)

        Ps.append(interp(mean_R, recall[::-1], precision[::-1]))

        plt.plot(recall, precision, lw=1.5, label=f"fold {i + 1} (AUPR = {aupr:.4f})")

    plt.plot([1, 0], [0, 1], linestyle="--", lw=1, alpha=0.5)

    mean_P = np.mean(Ps, axis=0)
    mean_aupr = np.mean(RPs)
    std_aupr = np.std(RPs, ddof=1)

    plt.plot(mean_R, mean_P, lw=1.5, label=f"Mean PR (AUPR = {mean_aupr:.4f} ± {std_aupr:.4f})")
    plt.xlabel("Recall", fontsize=14)
    plt.ylabel("Precision", fontsize=14)
    plt.legend()
    plt.savefig(save_path)
    plt.show()

    return mean_aupr, std_aupr


def run_mlp_5fold(feature_csv, output_txt="5-fold data.txt", seed=60):
    X = load_features(feature_csv)
    y = np.concatenate((np.ones(len(X) // 2), np.zeros(len(X) // 2)))

    clf = MLPClassifier(
        learning_rate_init=0.001,
        max_iter=1000,
        random_state=seed
    )

    skf = KFold(n_splits=5, shuffle=True, random_state=seed)

    metrics = {
        "precision": [], "recall": [], "f1_score": [],
        "accuracy": [], "mcc": [], "specificity": [],
        "auc": [], "aupr": []
    }

    with open(output_txt, "w") as f:
        f.write("\t\tAccuracy Precision Recall specificity F1-score MCC AUC AUPR\n")

    for fold, (train_idx, test_idx) in enumerate(skf.split(X, y), 1):
        X_train, y_train = X[train_idx], y[train_idx]
        X_test, y_test = X[test_idx], y[test_idx]

        fold_metrics = train_and_evaluate_fold(
            clf, X_train, y_train, X_test, y_test, fold, output_txt
        )
        for key, value in zip(metrics.keys(), fold_metrics):
            metrics[key].append(value)

    print("\nAverage Performance Metrics:")
    for key in metrics:
        print(f"Average {key}: {np.mean(metrics[key]):.4f}")

    mean_auc, std_auc = plot_roc_curves()
    mean_aupr, std_aupr = plot_pr_curves()

    with open(output_txt, "a") as f:
        f.write(
            f"Average\t{np.mean(metrics['accuracy']):.4f}\t"
            f"{np.mean(metrics['precision']):.4f}\t"
            f"{np.mean(metrics['recall']):.4f}\t"
            f"{np.mean(metrics['specificity']):.4f}\t"
            f"{np.mean(metrics['f1_score']):.4f}\t"
            f"{np.mean(metrics['mcc']):.4f}\t"
            f"{mean_auc:.4f}\t{mean_aupr:.4f}\n"
        )
        f.write(
            f"Std\t{np.std(metrics['accuracy'], ddof=1):.4f}\t"
            f"{np.std(metrics['precision'], ddof=1):.4f}\t"
            f"{np.std(metrics['recall'], ddof=1):.4f}\t"
            f"{np.std(metrics['specificity'], ddof=1):.4f}\t"
            f"{np.std(metrics['f1_score'], ddof=1):.4f}\t"
            f"{np.std(metrics['mcc'], ddof=1):.4f}\t"
            f"{std_auc:.4f}\t{std_aupr:.4f}\n"
        )


def main():
    set_seed(60)

    circ_disease_csv = "../../../../dataset/circRNA_disease.csv"
    mir_disease_csv = "../../../../dataset/miRNA_disease.csv"
    se_vector_csv = "../../Se_vector64.csv"

    pair_csv = "../../../../PositiveNegativeSamples.csv"

    node_emb_csv = "node_embeddings_15.csv"
    sample_feature_csv = "SampleFeature_15.csv"
    mlp_report_txt = "5-fold data.txt"

    G = build_graph(circ_disease_csv, mir_disease_csv)
    data, node_to_idx, idx_to_node, feat_dim = load_node_features(se_vector_csv, G)

    types = nx.get_node_attributes(G, "type")
    d_nodes = [n for n, t in types.items() if t == "disease"]
    c_nodes = [n for n, t in types.items() if t == "circRNA"]
    m_nodes = [n for n, t in types.items() if t == "miRNA"]

    edge_idx_dict = {
        "d_c_d": build_homogeneous_edge_index(G, node_to_idx, c_nodes, "circRNA", "disease", "d_c_d"),
        "d_m_d": build_homogeneous_edge_index(G, node_to_idx, m_nodes, "miRNA", "disease", "d_m_d"),
        "c_d_c": build_homogeneous_edge_index(G, node_to_idx, d_nodes, "disease", "circRNA", "c_d_c"),
        "m_d_m": build_homogeneous_edge_index(G, node_to_idx, d_nodes, "disease", "miRNA", "m_d_m"),
    }
    count_subgraph_nodes(edge_idx_dict, node_to_idx, G)

    train_hmmp_and_export_embeddings(
        G, data, edge_idx_dict,
        out_node_emb_csv=node_emb_csv,
        epochs=200,
        lr=0.001,
        weight_decay=1e-5,
        w_recon=1.0,
        noise_std=0.01,
    )

    feature_dict = read_feature_file(node_emb_csv, encoding="gbk")
    replace_id_pair_with_feature_pair(pair_csv, feature_dict, sample_feature_csv, encoding="gbk")

    run_mlp_5fold(sample_feature_csv, output_txt=mlp_report_txt, seed=60)


if __name__ == "__main__":
    main()
