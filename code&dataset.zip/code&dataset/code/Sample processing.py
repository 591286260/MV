import csv
import random
import warnings
from typing import List, Tuple, Set

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

SEED = 60
random.seed(SEED)
np.random.seed(SEED)


def read_lines(path: str, encoding: str = "utf-8") -> List[str]:
    with open(path, "r", encoding=encoding) as f:
        return f.readlines()


def read_pairs_from_csv(path: str, encoding: str = "utf-8") -> Set[Tuple[str, str]]:
    pairs: Set[Tuple[str, str]] = set()
    with open(path, "r", encoding=encoding, newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row or len(row) < 2:
                continue
            pairs.add((row[0].strip(), row[1].strip()))
    return pairs


def write_pairs_csv(pairs: List[Tuple[str, str]], out_path: str, encoding: str = "utf-8") -> None:
    with open(out_path, "w", encoding=encoding, newline="") as f:
        writer = csv.writer(f)
        writer.writerows(pairs)


def write_array_csv(arr: np.ndarray, out_path: str, encoding: str = "utf-8") -> None:
    with open(out_path, "w", encoding=encoding, newline="") as f:
        writer = csv.writer(f)
        writer.writerows(arr)


def parse_fasta_locations(fasta_lines: List[str]) -> List[Tuple[str, str]]:
    results: List[Tuple[str, str]] = []
    i = 0
    while i < len(fasta_lines):
        line = fasta_lines[i].strip()
        if line.startswith(">"):
            circ_id = line[1:].strip()
            if i + 1 >= len(fasta_lines):
                break
            location = fasta_lines[i + 1].strip()
            results.append((circ_id, location))
            i += 2
        else:
            i += 1
    return results


def read_excel_single_location(path: str, rows: int) -> List[Tuple[str, str]]:
    df = pd.read_excel(path, header=None).iloc[:rows, :2]
    return [(str(df.iat[i, 0]).strip(), str(df.iat[i, 1]).strip()) for i in range(len(df))]


def read_excel_dual_location(path: str, rows: int) -> List[Tuple[str, str, str]]:
    df = pd.read_excel(path, header=None).iloc[:rows, :3]
    return [
        (str(df.iat[i, 0]).strip(), str(df.iat[i, 1]).strip(), str(df.iat[i, 2]).strip())
        for i in range(len(df))
    ]


def generate_negative_pairs(
    circ_locations: List[Tuple[str, str]],
    mir_locations: List[Tuple[str, str]],
    mir_dual_locations: List[Tuple[str, str, str]],
    known_pairs: Set[Tuple[str, str]],
) -> List[Tuple[str, str]]:
    negatives: Set[Tuple[str, str]] = set()

    for circ_id, circ_loc in circ_locations:
        for mir_id, mir_loc in mir_locations:
            if circ_loc != mir_loc and (circ_id, mir_id) not in known_pairs:
                negatives.add((circ_id, mir_id))

    for circ_id, circ_loc in circ_locations:
        for mir_id, loc1, loc2 in mir_dual_locations:
            if circ_loc not in (loc1, loc2) and (circ_id, mir_id) not in known_pairs:
                negatives.add((circ_id, mir_id))

    return list(negatives)


def sample_pairs(pairs: List[Tuple[str, str]], k: int) -> List[Tuple[str, str]]:
    if len(pairs) < k:
        raise ValueError(f"Not enough candidate negatives: {len(pairs)} < {k}")
    return random.sample(pairs, k)


def main():
    positive_interaction_csv = "../../dataset/valid_CMI.csv"

    circRNA_fasta = "../../../dataset/721/circRNA_subcellular_lowercase.fasta"
    miRNA_excel = "../../../dataset/721/miRNA_subcellular.xlsx"
    miRNA_dual_excel = "../../../dataset/721/miRNA_subcellular2.xlsx"

    out_sampled_negative_csv = "NegativeSample.csv"
    out_all_negative_csv = "location_negative_sample.csv"
    out_combined_csv = "PositiveNegativeSamples.csv"

    known_pairs = read_pairs_from_csv(positive_interaction_csv)

    circ_lines = read_lines(circRNA_fasta)
    circ_locations = parse_fasta_locations(circ_lines)

    mir_locations = read_excel_single_location(miRNA_excel, rows=815)
    mir_dual_locations = read_excel_dual_location(miRNA_dual_excel, rows=6)

    all_negative_pairs = generate_negative_pairs(
        circ_locations=circ_locations,
        mir_locations=mir_locations,
        mir_dual_locations=mir_dual_locations,
        known_pairs=known_pairs,
    )

    sampled_negative_pairs = sample_pairs(all_negative_pairs, k=721)

    write_pairs_csv(sampled_negative_pairs, out_sampled_negative_csv)
    write_pairs_csv(all_negative_pairs, out_all_negative_csv)

    pos_list = list(known_pairs)
    pos_rows = np.array(pos_list, dtype=object)
    neg_rows = np.array(sampled_negative_pairs, dtype=object)

    print(f"Positive pairs: {len(pos_rows)}")
    print(f"Negative pairs: {len(neg_rows)}")

    combined = np.vstack([pos_rows, neg_rows])
    print(f"Combined shape: {combined.shape}")

    write_array_csv(combined, out_combined_csv)

    print("Done.")


if __name__ == "__main__":
    main()
